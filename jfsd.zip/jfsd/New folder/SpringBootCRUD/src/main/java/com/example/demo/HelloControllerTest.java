package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloControllerTest {
   private static Map<String, Hello> user = new HashMap<>();
   static {
      Hello obj1 = new Hello();
      obj1.setId("1");
      obj1.setName("Ankit");
      user.put(obj1.getId(), obj1);
      
      Hello obj2 = new Hello();
      obj2.setId("2");
      obj2.setName("Aniket");
      user.put(obj2.getId(), obj2);
   }
   
   @RequestMapping(value = "/users/{id}", method = RequestMethod.DELETE)
   public ResponseEntity<Object> delete(@PathVariable("id") String id) { 
      user.remove(id);
      return new ResponseEntity<>("Hello is deleted successsfully", HttpStatus.OK);
   }
   
   @RequestMapping(value = "/users/{id}", method = RequestMethod.PUT)
   public ResponseEntity<Object> updateHello(@PathVariable("id") String id, @RequestBody Hello userval) { 
      user.remove(id);
      userval.setId(id);
      user.put(id, userval);
      return new ResponseEntity<>("Hello is updated successsfully", HttpStatus.OK);
   }
   
   @RequestMapping(value = "/users", method = RequestMethod.POST)
   public ResponseEntity<Object> createHello(@RequestBody Hello userval) {
      user.put(userval.getId(), userval);
      return new ResponseEntity<>("Hello is created successfully", HttpStatus.CREATED);
   }
   
   @RequestMapping(value = "/users")
   public ResponseEntity<Object> getHello() {
      return new ResponseEntity<>(user.values(), HttpStatus.OK);
   }
   
   @GetMapping("/insertform")
   public String insertform(Model m) {
	   m.addAttribute("command", new Hello());
	   return "index";
   }
}