package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class ConversionController {
	@GetMapping("/conversion")
	@ResponseBody
	public Conversion calculate(@RequestParam String from, @RequestParam String to, @RequestParam int quantity) {
		Map<String, String> parameter = new HashMap<String, String>();
		parameter.put("from", from);
		parameter.put("to", to);
		ResponseEntity<Conversion> response = new RestTemplate().getForEntity("http://localhost:8080/h2currency/{from}/{to}/", Conversion.class, parameter);
		Conversion c1 = response.getBody();
		c1.setQuantity(quantity);
		c1.setTotal(quantity*c1.getRate());	
		
		return c1;
		
	}
}
