package com.klu.hibernate;   

import org.hibernate.Session;

import java.util.Iterator;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;    
import org.hibernate.Transaction;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.criterion.Restrictions;
  
    
@SuppressWarnings("deprecation")
public class StoreData {    
	public static void main(String[] args) {        
	    StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	          
	    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
	  
		SessionFactory factory = meta.getSessionFactoryBuilder().build();  
		Session session = factory.openSession();  
		Transaction t = session.beginTransaction();   
	    
		/*//Insert Example
	    Banking e1=new Banking();    
	    e1.setId(101);    
	    e1.setFirstName("Data");    
	    e1.setLastName("Store");  
	    session.save(e1);*/
	
		/*//Delete Example
		Query query=session.createQuery("delete from Banking where id=102");  
		query.executeUpdate();*/
	
		Query query=session.createQuery("select * from Banking");  
		query.setFirstResult(1);  
		query.setMaxResults(3);  
		List<Banking> list=query.list(); 
		System.out.println(list.get(0).getId());
	
		//Retrieve Data of ID - Similarly max, min, count, avg
		Query q=session.createQuery("select sum(id) from Banking");  
		List<Integer> list1=q.list();  
		System.out.println(list1.get(0));
	    
		//Cretieria for condition based retrieval
		/*Criteria c=session.createCriteria(Banking.class);  
		c.add(Restrictions.gt("id",102));//salary is the propertyname  
		List<Banking> list=c.list();  
		System.out.println(list.get(0).getId());*/
		
		//c.addOrder(Order.asc("id"));  
		//c.setProjection(Projections.property("firstName"));  
		//c.setFirstResult(10);  
		//c.setMaxResult(20);  
	
		/*TypedQuery query = session.getNamedQuery("findBankingByName");    
		query.setParameter("name","Balajee");   
	        
		List<Banking> Bankings=query.getResultList();   
	
		Iterator<Banking> itr=Bankings.iterator();    
		while(itr.hasNext()){    
			Banking e=itr.next();    
			System.out.println(e.getId());    
		}*/   
		
	    t.commit();  
	    System.out.println("successfully done");    
	    factory.close();  
	    session.close();    
	        
	}    
}   