package com.example.controllers;   
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.beans.Dept;
import com.example.dao.DeptDao;  
@Controller  
public class DeptController {  
    @Autowired  
    DeptDao dao;//will inject dao from xml file  
      
    /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */  
    @RequestMapping("/deptform")  
    public String showform(Model m){  
    	System.out.println("dept form function");
    	m.addAttribute("command", new Dept());
    	return "empform"; 
    }  
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("dept") Dept dept){  
        dao.save(dept);  
        return "redirect:/viewemp/1";//will redirect to viewemp request mapping  
    }  
    /* It provides list of employees in model object */  
    @RequestMapping("/viewemp/{page}")  
    public String viewemp(@PathVariable("page")int page, Model m){  
    	page = (page-1)*2;
        List<Dept> list=dao.getDept(page);  
        m.addAttribute("list",list);
        return "viewemp";  
    }   
    @RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao.delete(id);  
        return "redirect:/viewemp";  
    }   
}  