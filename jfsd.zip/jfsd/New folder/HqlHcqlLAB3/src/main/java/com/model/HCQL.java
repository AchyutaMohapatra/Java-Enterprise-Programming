package com.model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

public class HCQL {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		Criteria cr = null;
		List<Student> list = null;
		 cr = session.createCriteria(Student.class)
			    .setProjection(Projections.projectionList()
			      .add(Projections.property("id"), "id")
			      .add(Projections.property("name"), "name"))
			    .setResultTransformer(Transformers.aliasToBean(Student.class));

			   list = cr.list();
			  System.out.println("7. Specific columns from student table");
			  System.out.println("ID\t\tNAME");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName() );
			  }
			  
			  list.removeAll(list);
			  System.out.println("\n\n8. HCQL query to fetch only some records");
			  cr=session.createCriteria(Student.class);  
			  cr.setFirstResult(2);  
			  cr.setMaxResults(3);
			  list = cr.list();
			  System.out.println("ID\t\tNAME");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName() );
			  }
			  list.removeAll(list);
			  System.out.println("\n\n9.  greater than, less than, greater than equal to, less than equal to, equal to and not equal");
			  cr=session.createCriteria(Student.class); 
			  cr.add(Restrictions.gt("cgpa", 7.5));
			  list = cr.list();
			  System.out.println("\ncgpa>7.5");
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  list.removeAll(list);
			  System.out.println("\ncgpa>=8.52");
			  cr=session.createCriteria(Student.class);
			  cr.add(Restrictions.ge("cgpa", 8.52));
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);
			  System.out.println("\ncgpa<7.5");
			  cr.add(Restrictions.lt("cgpa", 7.5));
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);
			  System.out.println("\ncgpa<=7.5");
			  cr.add(Restrictions.le("cgpa", 7.5));
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);
			  System.out.println("\ncgpa = 8.52");
			  cr.add(Restrictions.eq("cgpa", 8.52));
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);
			  System.out.println("\ncgpa != 8.52");
			  cr.add(Restrictions.ne("cgpa", 8.52));
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  

			  System.out.println("\n\n10.Ascending order by cgpa");
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);  
			  cr.addOrder(Order.asc("cgpa")); 
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			  System.out.println("\n\n10.Descending order by cgpa");
			  list.removeAll(list);
			  cr=session.createCriteria(Student.class);  
			  cr.addOrder(Order.desc("cgpa")); 
			  list = cr.list();
			  System.out.println("ID\t\tNAME\tCGPA");
			  for(Student s:list) {
				  System.out.println(s.getId()+" \t"+s.getName()+"\t"+s.getCgpa());
			  }
			 
			  
			  
			  
			  
			  
			 
			  

	}

}
