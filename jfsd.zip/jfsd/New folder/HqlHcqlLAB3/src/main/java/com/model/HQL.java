package com.model;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class HQL {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		
		String qry = "from Student";
		Query q = session.createQuery(qry);
		List<Student> list = q.list();
		System.out.println("1. All Student List");
		System.out.println("ID\t\t"+ "NAME\t\t"+"DOB\t\t"+ "PROGRAM\t\t"+"DEPT.\t\t"+ "MOBILE\t\t"+"CGPA\t\t"+ "G.STATUS\t\t"+"BACKLOG\t\t");
		for(Student s: list) {
			System.out.println(s.getId()+"\t\t"+s.getName()+"\t\t"+s.getDob()+"\t\t"+s.getPgm()+"\t\t"+s.getDept()+"\t\t"+s.getMobile()+"\t\t"+s.getCgpa()+"\t\t"+s.getGstatus()+"\t\t"+s.getBacklog()+"\t\t");
		}
		
		System.out.println("\n\n2. All Student with selected columns");
		
		System.out.println("ID\t\t"+ "NAME\t\t"+"DOB\t\t"+ "PROGRAM\t\t"+"DEPT.\t\t"+ "MOBILE\t\t");
		for(Student s: list) {
			System.out.println(s.getId()+"\t\t"+s.getName()+"\t\t"+s.getDob()+"\t\t"+s.getPgm()+"\t\t"+s.getDept()+"\t\t"+s.getMobile());
		}
		
		System.out.println("\n\n3. Student name cgpa>7");
		String qry1 = "from Student where cgpa>7";
		Query q1 = session.createQuery(qry1);
		List<Student> l = q1.list();
		
		for(Student s: l) {
			System.out.println(s.getName() + "  -  CGPA:  " +s.getCgpa());
		}
		
		System.out.println("\n\n4. Deleting Student id- 30101");
		Transaction tx1 = session.beginTransaction();
		Query query1=session.createQuery("delete from Student where id=:id"); 
		query1.setParameter("id", 30101);
		int j =query1.executeUpdate();
		tx1.commit();
		if(j>0) {
			System.out.println("30101 deleted Successfully");
		}
		
		System.out.println("\n\n5. updating Student id- 30102");
		Transaction tx = session.beginTransaction();
		Query query=session.createQuery("update Student set name=:name where id=:id "); 
		query.setParameter("name", "Akhil");
		query.setParameter("id", 30102);
		int i =query.executeUpdate(); 
		tx.commit();
		if(i>0) {
		System.out.println("30102 updated Successfully");
		}
		
		System.out.println("\n\n5. updating Student id- 30102");
		
		System.out.println("\n\n6. count sum avg min max by hql");
		Query q2=session.createQuery("select sum(cgpa) from Student");
		List<Integer> li = q2.list();
		System.out.println("sum of cgpa: " +li.get(0));
		Query q3=session.createQuery("select max(cgpa) from Student");
		List<Integer> l2 = q3.list();
		System.out.println("max cgpa: " +l2.get(0));
		Query q4=session.createQuery("select min(cgpa) from Student");
		List<Integer> l3 = q4.list();
		System.out.println("min cgpa: " +l3.get(0));
		Query q5=session.createQuery("select count(id) from Student");
		List<Integer> l4 = q5.list();
		System.out.println("Countof student: " +l4.get(0));
		
		

	}

}
