package com.klu.springhibernate;

import org.springframework.orm.hibernate3.HibernateTemplate;  
import java.util.*; 

public class DeptDao {  
HibernateTemplate template;  
public void setTemplate(HibernateTemplate template) {  
    this.template = template;  
}  
//method to save employee  
public void saveDept(Dept e){  
    template.save(e);  
}  
//method to update employee  
public void updateDept(Dept e){  
    template.update(e);  
}  
//method to delete employee  
public void deleteDept(Dept e){  
    template.delete(e);  
}  
//method to return one employee of given id  
public Dept getById(int id){  
    Dept e=(Dept)template.get(Dept.class,id);  
    return e;  
}  
//method to return all employees  
public List<Dept> getDepts(){  
    List<Dept> list=new ArrayList<Dept>();  
    list=template.loadAll(Dept.class);  
    return list;  
}  
}  

