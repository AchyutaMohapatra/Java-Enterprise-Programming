package com.klu.springhibernate;

import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  
  
public class InsertTest {  
public static void main(String[] args) {  
      
    Resource r=new ClassPathResource("applicationContext.xml");  
    BeanFactory factory=new XmlBeanFactory(r);  
      
    DeptDao dao=(DeptDao)factory.getBean("d");  
      
    Dept e=new Dept();  
    e.setId(3);  
    e.setName("CSE");  
    dao.saveDept(e);  
      
	}  
}
