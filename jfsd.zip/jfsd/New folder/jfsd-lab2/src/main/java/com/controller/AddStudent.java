package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Student;
import com.model.StudentManager;

@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		int id = Integer.parseInt(request.getParameter("t1"));
		String name =  request.getParameter("t2");
		String dept =  request.getParameter("t3");
		String pgm =  request.getParameter("t4");
		String dob =  request.getParameter("t5");
		String mobile =  request.getParameter("t6");
		String gstatus =  request.getParameter("t7");
		double cgpa = Double.parseDouble(request.getParameter("t8"));
		int backlog = Integer.parseInt(request.getParameter("t9"));
		
	try {
		Student s = new Student();
		s.setId(id);
		s.setName(name);
		s.setDept(dept);
		s.setPgm(pgm);
		s.setDob(dob);
		s.setMobile(mobile);
		s.setGstatus(gstatus);
		s.setCgpa(cgpa);
		s.setBacklog(backlog);
		StudentManager sm = new StudentManager();
		
		String ack = sm.insert(s);
		pw.print(ack);
	} catch (Exception e) {
		pw.print(e.getMessage());
	}
	
	RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
	rd.include(request, response);
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
