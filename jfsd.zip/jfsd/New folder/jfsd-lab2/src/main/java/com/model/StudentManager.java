package com.model;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.TypedQuery;

public class StudentManager {
	
	public String insert(Student s) {
		String ack = "";
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		try {
			session.getTransaction().begin();
			session.persist(s);
			session.getTransaction().commit();
			ack = "Data inserted for Student...";

		} catch (Exception e2) {
			session.getTransaction().rollback();
			ack = e2.getMessage();
		}
		session.close();
		factory.close();
		return ack;
	}
	
	public Student getById(int id) {
		Student s = null;
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		try {
			session.getTransaction().begin();
			TypedQuery<Student> qry = session.createQuery("SELECT s FROM Student s WHERE s.id=:id" , Student.class); 
			//Student s = session.find(Student.class, id);
			qry.setParameter("id", id);
			s = qry.getSingleResult();
			session.getTransaction().commit();
			
		} catch (Exception e) {
			session.getTransaction().rollback();
			System.out.println(e.getMessage());
		}
		session.close();
		factory.close();
		
return s;
	}
	
	public String update(int id, double cgpa, int backlog) {
		String ack = "";
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		
		try {
			session.getTransaction().begin();
			Student s = session.find(Student.class, id);
			s.setCgpa(cgpa);
			s.setBacklog(backlog);
			session.getTransaction().commit();
			ack = "Updated successfully...";
			
		} catch (Exception e) {
			session.getTransaction().rollback();
			ack = e.getMessage();
		}
		return ack;
	}
	
	public String delete(int id) {
		String ack="";
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		
		try {
			session.getTransaction().begin();
			Student s = session.find(Student.class, id);
			session.remove(s);
			ack = "Deleted Student record";
			session.getTransaction().commit();
			
			
		}
		catch (Exception e) {
			session.getTransaction().rollback();
			ack = e.getMessage();
		}
		session.close();
		factory.close();
		
		
		return ack;
	}

}
