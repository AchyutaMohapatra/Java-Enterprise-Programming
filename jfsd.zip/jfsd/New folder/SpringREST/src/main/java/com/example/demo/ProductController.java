package com.example.demo;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
 
import org.springframework.web.bind.annotation.*;
 
@RestController
public class ProductController {
 
    @Autowired
    private ProductService service;
     
    //Retrieve products
    @GetMapping("/products")
    public List<Students> list() {
        return service.listAll();
    }
    
    //Retrieve a specific product
    @GetMapping("/products/{id}")
    public ResponseEntity<Students> get(@PathVariable Integer id) {
        try {
            Students students = service.get(id);
            return new ResponseEntity<Students>(students, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<Students>(HttpStatus.NOT_FOUND);
        }      
    }
    
    //Create a product
    @PostMapping("/products")
    public void add(@RequestBody Students students) {
        service.save(students);
    }
    
    //Update operation
    @PutMapping("/products/{id}")
    public ResponseEntity<?> update(@RequestBody Students students, @PathVariable Integer id) {
        try {
            Students existProduct = service.get(id);
            service.save(students);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }      
    }
    
    //Delete operation
    @DeleteMapping("/products/{id}")
    public void delete(@PathVariable Integer id) {
        service.delete(id);
    }
}