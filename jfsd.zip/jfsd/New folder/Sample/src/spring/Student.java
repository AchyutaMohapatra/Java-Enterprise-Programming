package spring;

import java.util.List;

public class Student {  
private String name;
private Address address;
private List<Friend> friend;
public Student(String name,Address address,List<Friend> friend) {
  this.name=name;
  this.address=address;
  this.friend=friend;
}
  

public List<Friend> getFriend() {
  return friend;
}

public void setFriend(List<Friend> friend) {
  this.friend = friend;
}

public Address getAddress() {
  return address;
}

public void setAddress(Address address) {
  this.address = address;
}

public String getName() {  
    return name;  
}  
  
public void setName(String name) {  
    this.name = name;  
}  
  
public void displayInfo(){  
    System.out.println("Hello: "+name);
    System.out.println(address);
    System.out.println(friend);
}  
}