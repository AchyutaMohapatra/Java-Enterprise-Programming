package spring;

public class Friend {
	private int id;
	private String name;
	
	public Friend(int id, String name) {
		this.id=id;
		this.name=name;
	}
	@Override
	public String toString() {
		return "id=" + String.valueOf(id) + ", name=" + name;
	}
	
}
