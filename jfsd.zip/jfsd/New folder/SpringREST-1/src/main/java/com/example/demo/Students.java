package com.example.demo;

import org.springframework.boot.autoconfigure.domain.EntityScan;

public class Students {
    private int id;
    private String name;
    private String gender;
    private String deparetment;
    
 
    public Students() {
    }

 
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getDeparetment() {
		return deparetment;
	}


	public void setDeparetment(String deparetment) {
		this.deparetment = deparetment;
	}
 
    
    
}