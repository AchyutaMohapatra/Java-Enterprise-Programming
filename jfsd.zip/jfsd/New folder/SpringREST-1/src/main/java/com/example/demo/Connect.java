package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Connect {
	
	public static Connection connect() {
		String url ="jdbc:mysql://localhost:3306/jfsd";
		String user = "root";
		String pass = "Ankit@25";
		try {
			Connection con = DriverManager.getConnection(url,user,pass);
			return con;
		} catch (SQLException e) {
			
			return null;
		}
		
	}
	
	public static String insert(Students s) {
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement("insert into Students values(?,?,?,?)");
			ps.setInt(1, s.getId());
			ps.setString(2, s.getName());
			ps.setString(3, s.setDeparetment(null));
			
			
		} catch (SQLException e) {
			return e.getMessage();
			e.printStackTrace();
		}
		
	}

}
